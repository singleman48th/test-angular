'''
python-lambda-local: tests module.

Meant for use with py.test.
Organize tests into files, each named xxx_test.py
Read more here: http://pytest.org/

Copyright 2015-2019 HENNGE K.K. (formerly known as HDE, Inc.)
Licensed under MIT
'''
